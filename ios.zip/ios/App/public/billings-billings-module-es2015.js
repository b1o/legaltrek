(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["billings-billings-module"],{

/***/ "7Gla":
/*!*********************************************!*\
  !*** ./src/app/billings/billings.module.ts ***!
  \*********************************************/
/*! exports provided: BillingsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BillingsModule", function() { return BillingsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _billing_detail_page_billing_detail_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./billing-detail-page/billing-detail-page.component */ "jukA");
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../material/material.module */ "hctd");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _add_billing_page_add_billing_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./add-billing-page/add-billing-page.component */ "sTpI");
/* harmony import */ var _billings_page_billings_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./billings-page/billings-page.component */ "dO7M");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");











const routes = [
    { path: '', component: _billings_page_billings_page_component__WEBPACK_IMPORTED_MODULE_9__["BillingsPageComponent"] },
    { path: 'add', component: _add_billing_page_add_billing_page_component__WEBPACK_IMPORTED_MODULE_8__["AddBillingPageComponent"] },
];
let BillingsModule = class BillingsModule {
};
BillingsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_billing_detail_page_billing_detail_page_component__WEBPACK_IMPORTED_MODULE_3__["BillingDetailPageComponent"], _billings_page_billings_page_component__WEBPACK_IMPORTED_MODULE_9__["BillingsPageComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterModule"].forChild(routes),
            _material_material_module__WEBPACK_IMPORTED_MODULE_4__["MaterialModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_10__["SharedModule"],
        ],
    })
], BillingsModule);



/***/ }),

/***/ "CKV0":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/billings/add-billing-page/add-billing-page.component.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  add-billing-page works!\n</p>\n");

/***/ }),

/***/ "CToy":
/*!*********************************************************************!*\
  !*** ./src/app/billings/billings-page/billings-page.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".content {\n  display: flex;\n  flex-direction: column;\n}\n\n.hours, .bottom {\n  display: flex;\n  justify-content: space-between;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxiaWxsaW5ncy1wYWdlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsYUFBQTtFQUNBLHNCQUFBO0FBQ0Q7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7QUFDSiIsImZpbGUiOiJiaWxsaW5ncy1wYWdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRlbnQge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuLmhvdXJzLCAuYm90dG9tIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn0iXX0= */");

/***/ }),

/***/ "Kb+2":
/*!*********************************************************************************!*\
  !*** ./src/app/billings/billing-detail-page/billing-detail-page.component.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiaWxsaW5nLWRldGFpbC1wYWdlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "PPQO":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/billings/billing-detail-page/billing-detail-page.component.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  billing-detail-page works!\n</p>\n");

/***/ }),

/***/ "QOR6":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/billings/billings-page/billings-page.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"ion-padding\">\r\n\t<div\r\n\t\tclass=\"ion-margin-top\"\r\n\t\tstyle=\"background-color: white\"\r\n\t\t*ngFor=\"let entry of billings\"\r\n\t>\r\n\t\t<app-billing [entry]=\"entry\"></app-billing>\r\n\t</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "dO7M":
/*!*******************************************************************!*\
  !*** ./src/app/billings/billings-page/billings-page.component.ts ***!
  \*******************************************************************/
/*! exports provided: BillingsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BillingsPageComponent", function() { return BillingsPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_billings_page_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./billings-page.component.html */ "QOR6");
/* harmony import */ var _billings_page_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./billings-page.component.scss */ "CToy");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _billings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../billings.service */ "8orH");





let BillingsPageComponent = class BillingsPageComponent {
    constructor(billingsService) {
        this.billingsService = billingsService;
        this.billings = [];
    }
    ngOnInit() {
        this.billingsService.getBillings()
            .subscribe((res) => {
            console.log(res);
            this.billings = Object.keys(res.billings).map(key => (Object.assign({ id: key }, res.billings[key])));
        });
    }
};
BillingsPageComponent.ctorParameters = () => [
    { type: _billings_service__WEBPACK_IMPORTED_MODULE_4__["BillingsService"] }
];
BillingsPageComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-billings-page',
        template: _raw_loader_billings_page_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_billings_page_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BillingsPageComponent);



/***/ }),

/***/ "jukA":
/*!*******************************************************************************!*\
  !*** ./src/app/billings/billing-detail-page/billing-detail-page.component.ts ***!
  \*******************************************************************************/
/*! exports provided: BillingDetailPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BillingDetailPageComponent", function() { return BillingDetailPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_billing_detail_page_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./billing-detail-page.component.html */ "PPQO");
/* harmony import */ var _billing_detail_page_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./billing-detail-page.component.scss */ "Kb+2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let BillingDetailPageComponent = class BillingDetailPageComponent {
    constructor() { }
    ngOnInit() { }
};
BillingDetailPageComponent.ctorParameters = () => [];
BillingDetailPageComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-billing-detail-page',
        template: _raw_loader_billing_detail_page_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_billing_detail_page_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BillingDetailPageComponent);



/***/ }),

/***/ "sTpI":
/*!*************************************************************************!*\
  !*** ./src/app/billings/add-billing-page/add-billing-page.component.ts ***!
  \*************************************************************************/
/*! exports provided: AddBillingPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddBillingPageComponent", function() { return AddBillingPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_add_billing_page_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./add-billing-page.component.html */ "CKV0");
/* harmony import */ var _add_billing_page_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./add-billing-page.component.scss */ "xQed");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let AddBillingPageComponent = class AddBillingPageComponent {
    constructor() { }
    ngOnInit() { }
};
AddBillingPageComponent.ctorParameters = () => [];
AddBillingPageComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-billing-page',
        template: _raw_loader_add_billing_page_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_add_billing_page_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AddBillingPageComponent);



/***/ }),

/***/ "xQed":
/*!***************************************************************************!*\
  !*** ./src/app/billings/add-billing-page/add-billing-page.component.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZGQtYmlsbGluZy1wYWdlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ })

}]);
//# sourceMappingURL=billings-billings-module-es2015.js.map