(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! C:\ionic\legaltrek\src\main.ts */
      "zUnb");
      /***/
    },

    /***/
    "8hpD":
    /*!*******************************************!*\
      !*** ./src/app/services/timer.service.ts ***!
      \*******************************************/

    /*! exports provided: TimerService */

    /***/
    function hpD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TimerService", function () {
        return TimerService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _network_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./network.service */
      "dwY0");
      /* harmony import */


      var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/background-mode/ngx */
      "1xeP");
      /* harmony import */


      var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/local-notifications/ngx */
      "Bg0J");
      /* harmony import */


      var _matters_matters_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../matters/matters.service */
      "rayq");

      var TimerService = /*#__PURE__*/function () {
        function TimerService(actionSheetController, network, alertController, backgroundMode, localNotifications, zone, matterService) {
          var _this = this;

          _classCallCheck(this, TimerService);

          this.actionSheetController = actionSheetController;
          this.network = network;
          this.alertController = alertController;
          this.backgroundMode = backgroundMode;
          this.localNotifications = localNotifications;
          this.zone = zone;
          this.matterService = matterService;
          this.isRunning = false;
          this.isPaused = false;
          this.timer = 0;
          this.ticker = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["interval"])(1000);
          this.pausedButtons = [{
            id: 'resume',
            title: 'Resume',
            icon: 'res://resume',
            foreground: true
          }, {
            foreground: true,
            id: 'stop',
            title: 'Stop',
            icon: 'res://stop'
          }];
          this.defaultButtons = [{
            id: 'pause',
            title: 'Pause',
            icon: 'res://pause',
            foreground: true
          }, {
            foreground: true,
            id: 'stop',
            title: 'Stop',
            icon: 'res://stop'
          }];
          this.toTimerFormat();
          this.pauseTimer = this.pauseTimer.bind(this);
          this.stopTimer = this.stopTimer.bind(this);
          this.startTimer = this.startTimer.bind(this);
          this.confirmTimerStop = this.confirmTimerStop.bind(this);
          this.localNotifications.on('pause').subscribe(function (data) {
            return _this.zone.run(function (_) {
              _this.pauseTimer();
            });
          });
          this.localNotifications.on('stop').subscribe(function (data) {
            return _this.zone.run(function () {
              return _this.confirmTimerStop();
            });
          });
          this.localNotifications.on('resume').subscribe(function (data) {
            return _this.zone.run(function (_) {
              _this.startTimer();
            });
          });
        }

        _createClass(TimerService, [{
          key: "tick",
          value: function tick() {
            this.timer++;
            this.toTimerFormat();
            this.localNotifications.update({
              id: 1,
              text: this.timerFormatted
            });
          }
        }, {
          key: "confirmTimerStop",
          value: function confirmTimerStop() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this2 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.backgroundMode.moveToForeground();
                      _context.next = 3;
                      return this.alertController.create({
                        header: 'Save timer?',
                        message: 'Do you wish to save this timer?',
                        buttons: [{
                          text: 'No',
                          role: 'cancel',
                          handler: function handler() {
                            return _this2.saveTimer();
                          }
                        }, {
                          text: 'Yes',
                          handler: function handler() {
                            return _this2.stopTimer();
                          }
                        }]
                      });

                    case 3:
                      alert = _context.sent;
                      _context.next = 6;
                      return alert.present();

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "saveTimer",
          value: function saveTimer() {
            // TODO: save timer
            this.stopTimer();
          }
        }, {
          key: "openTimerSheet",
          value: function openTimerSheet() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this3 = this;

              var buttons, actionSheet;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      buttons = [];

                      if (this.isPaused && !this.isRunning || !this.isPaused && !this.isRunning) {
                        buttons.push({
                          text: !this.isPaused ? 'Start timer' : 'Resume timer',
                          icon: 'play',
                          handler: function handler() {
                            return _this3.startTimer();
                          }
                        });
                      }

                      if (this.isPaused || this.isRunning) {
                        buttons.push({
                          text: 'Stop timer',
                          icon: 'stop',
                          handler: function handler() {
                            return _this3.stopTimer();
                          }
                        });
                      }

                      if (this.isRunning) {
                        buttons.push({
                          text: 'Pause timer',
                          icon: 'pause',
                          handler: function handler() {
                            return _this3.pauseTimer();
                          }
                        });
                      }

                      _context2.next = 6;
                      return this.actionSheetController.create({
                        header: 'Timer',
                        buttons: [].concat(buttons, [{
                          text: 'Cancel',
                          icon: 'close',
                          role: 'cancel',
                          handler: function handler() {}
                        }])
                      });

                    case 6:
                      actionSheet = _context2.sent;
                      _context2.next = 9;
                      return actionSheet.present();

                    case 9:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "toTimerFormat",
          value: function toTimerFormat() {
            var hours = Math.floor(this.timer / 3600);
            var minutes = Math.floor((this.timer - hours * 3600) / 60);
            var seconds = this.timer - hours * 3600 - minutes * 60;

            if (hours < 10) {
              hours = '0' + hours;
            }

            if (minutes < 10) {
              minutes = '0' + minutes;
            }

            if (seconds < 10) {
              seconds = '0' + seconds;
            }

            this.timerFormatted = hours + ':' + minutes + ':' + seconds;
          }
        }, {
          key: "startTimer",
          value: function startTimer() {
            var _this4 = this;

            this.isRunning = true;
            this.isPaused = false;
            this.localNotifications.schedule({
              id: 1,
              title: this.matterService.currentMatter ? this.matterService.currentMatter.matter : null,
              text: this.timerFormatted,
              autoClear: false,
              lockscreen: true,
              sticky: true,
              vibrate: false,
              actions: this.defaultButtons
            }); // this.backgroundMode.on('enable').subscribe(() => {
            // 	console.log('background  mode');
            // });

            this.tickerSub = this.ticker.subscribe(function () {
              return _this4.tick();
            });
            this.backgroundMode.enable();
          }
        }, {
          key: "stopTimer",
          value: function stopTimer() {
            this.isRunning = false;
            this.isPaused = false;
            this.timer = 0;
            this.toTimerFormat();
            this.currentTimerId = null;
            this.tickerSub.unsubscribe();
            this.backgroundMode.disable();
            this.localNotifications.clear(1);
          }
        }, {
          key: "pauseTimer",
          value: function pauseTimer() {
            this.isRunning = false;
            this.isPaused = true;
            this.localNotifications.update({
              id: 1,
              actions: this.pausedButtons
            });
            this.tickerSub.unsubscribe();
          }
        }]);

        return TimerService;
      }();

      TimerService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
        }, {
          type: _network_service__WEBPACK_IMPORTED_MODULE_4__["NetworkService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
        }, {
          type: _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_5__["BackgroundMode"]
        }, {
          type: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_6__["LocalNotifications"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"]
        }, {
          type: _matters_matters_service__WEBPACK_IMPORTED_MODULE_7__["MattersService"]
        }];
      };

      TimerService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], TimerService);
      /***/
    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./app.component.html */
      "VzVu");
      /* harmony import */


      var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app.component.scss */
      "ynWL");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "54vc");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "VYYF");
      /* harmony import */


      var _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./auth/auth.service */
      "qXBG");
      /* harmony import */


      var _services_timer_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./services/timer.service */
      "8hpD");
      /* harmony import */


      var _matters_matters_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./matters/matters.service */
      "rayq");

      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBar, authService, menuController, timerService, matterService) {
          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBar = statusBar;
          this.authService = authService;
          this.menuController = menuController;
          this.timerService = timerService;
          this.matterService = matterService;
          this.showSearchBar = false;
          this.searchResults = [];
          this.initializeApp();
        }

        _createClass(AppComponent, [{
          key: "initializeApp",
          value: function initializeApp() {
            this.platform.ready().then(function () {});
          }
        }, {
          key: "toggleSideMenu",
          value: function toggleSideMenu() {
            this.menuController.toggle('settings');
          }
        }, {
          key: "titleClicked",
          value: function titleClicked() {
            if (this.timerService.isRunning || this.timerService.isPaused) {
              this.timerService.openTimerSheet();
            }
          }
        }, {
          key: "toggleSearchBar",
          value: function toggleSearchBar() {
            this.showSearchBar = !this.showSearchBar;
          }
        }, {
          key: "logout",
          value: function logout() {
            this.authService.logout();
          }
        }, {
          key: "search",
          value: function search(event) {
            var _this5 = this;

            var term = event.detail.value;
            this.matterService.search(term).subscribe(function (data) {
              return _this5.searchResults = data;
            });
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"]
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"]
        }, {
          type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"]
        }, {
          type: _services_timer_service__WEBPACK_IMPORTED_MODULE_8__["TimerService"]
        }, {
          type: _matters_matters_service__WEBPACK_IMPORTED_MODULE_9__["MattersService"]
        }];
      };

      AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], AppComponent);
      /***/
    },

    /***/
    "VzVu":
    /*!**************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function VzVu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app>\n\t<ion-menu side=\"start\" menuId=\"settings\" contentId=\"main\">\n\t\t<ion-header>\n\t\t\t<ion-toolbar color=\"primary\">\n\t\t\t\t<ion-title>Settings</ion-title>\n\t\t\t</ion-toolbar>\n\t\t</ion-header>\n\t\t<ion-content class=\"sidemenu-container\">\n\t\t\t<ion-list>\n\t\t\t\t<!-- <ion-menu-toggle [autoHide]=\"true\">\n\t\t\t\t\t<ion-item [lines]=\"'none'\" routerLink=\"/auth/login\"\n\t\t\t\t\t\t>Login</ion-item\n\t\t\t\t\t>\n\t\t\t\t\t<ion-item [lines]=\"'none'\" routerLink=\"/auth/reset-password\"\n\t\t\t\t\t\t>Forgot Password</ion-item\n\t\t\t\t\t>\n\t\t\t\t\t<ion-item [lines]=\"'none'\" routerLink=\"/home\"\n\t\t\t\t\t\t>Home</ion-item\n\t\t\t\t\t>\n        </ion-menu-toggle> -->\n\t\t\t\t<ion-item>\n\t\t\t\t\t<ion-label>Language</ion-label>\n\t\t\t\t\t<ion-select value=\"bg\" okText=\"Okay\" cancelText=\"Dismiss\">\n\t\t\t\t\t\t<ion-select-option value=\"bg\"\n\t\t\t\t\t\t\t>English</ion-select-option\n\t\t\t\t\t\t>\n\t\t\t\t\t\t<ion-select-option value=\"en\"\n\t\t\t\t\t\t\t>Bulgarian</ion-select-option\n\t\t\t\t\t\t>\n\t\t\t\t\t</ion-select>\n\t\t\t\t</ion-item>\n\t\t\t\t<ion-item>\n\t\t\t\t\t<ion-label>Notifications</ion-label>\n\t\t\t\t\t<ion-toggle></ion-toggle>\n\t\t\t\t</ion-item>\n\n\t\t\t\t<ion-item>\n\t\t\t\t\t<ion-label>Timer bubble</ion-label>\n\t\t\t\t\t<ion-toggle></ion-toggle>\n\t\t\t\t</ion-item>\n\t\t\t</ion-list>\n\t\t\t<div class=\"spacer\"></div>\n\t\t\t<ion-button\n\t\t\t\t(click)=\"logout()\"\n\t\t\t\tclass=\"ion-justify-self-end\"\n\t\t\t\texpand=\"full\"\n\t\t\t\tcolor=\"primary\"\n\t\t\t\t>Logout <ion-icon name=\"log-out\" slot=\"end\"></ion-icon\n\t\t\t></ion-button>\n\t\t</ion-content>\n\t</ion-menu>\n\n\t<ion-header text-center class=\"ion-no-border\">\n\t\t<ion-toolbar color=\"primary\">\n\t\t\t<ion-back-button [icon]=\"'home'\" slot=\"start\"></ion-back-button>\n\t\t\t<ion-buttons slot=\"end\">\n\t\t\t\t<ion-button (click)=\"toggleSearchBar()\">\n\t\t\t\t\t<ion-icon\n\t\t\t\t\t\tname=\"{{ showSearchBar ? 'close' : 'search' }}\"\n\t\t\t\t\t></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t\t<ion-button (click)=\"toggleSideMenu()\">\n\t\t\t\t\t<ion-icon name=\"settings\"></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t</ion-buttons>\n\n\t\t\t<ion-title [color]=\"timerService.isPaused ? 'warning' : 'light'\">\n\t\t\t\t<div *ngIf=\"!timerService.isPaused && !timerService.isRunning\">\n\t\t\t\t\tLegaltrek\n\t\t\t\t</div>\n\t\t\t\t<div\n\t\t\t\t\tstyle=\"display: flex; align-items: center;\"\n\t\t\t\t\t*ngIf=\"timerService.isPaused || timerService.isRunning\"\n\t\t\t\t>\n\t\t\t\t\t{{ timerService.timerFormatted }}\n\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t(click)=\"timerService.startTimer()\"\n\t\t\t\t\t\t*ngIf=\"timerService.isPaused\"\n\t\t\t\t\t\tname=\"play\"\n\t\t\t\t\t></ion-icon>\n\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t(click)=\"timerService.pauseTimer()\"\n\t\t\t\t\t\t*ngIf=\"timerService.isRunning && !timerService.isPaused\"\n\t\t\t\t\t\tname=\"pause\"\n\t\t\t\t\t></ion-icon>\n\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t(click)=\"timerService.confirmTimerStop()\"\n\t\t\t\t\t\t*ngIf=\"timerService.isRunning || timerService.isPaused\"\n\t\t\t\t\t\tname=\"stop\"\n\t\t\t\t\t></ion-icon>\n\t\t\t\t</div>\n\t\t\t</ion-title>\n\t\t</ion-toolbar>\n\t\t<ion-toolbar *ngIf=\"showSearchBar\" color=\"primary\">\n\t\t\t<ion-searchbar\n\t\t\t\t[debounce]=\"300\"\n\t\t\t\t(ionChange)=\"search($event)\"\n\t\t\t\tanimated\n\t\t\t></ion-searchbar>\n\t\t\t\t<ion-list\n\t\t\t\t\tstyle=\"max-height: 300px; width: 97%; overflow-y: scroll; border: 1px solid; margin: 0 auto\"\n\t\t\t\t\t*ngIf=\"showSearchBar && searchResults.length > 0\"\n\t\t\t\t>\n\t\t\t\t\t<ion-item *ngFor=\"let item of searchResults\">{{\n\t\t\t\t\t\titem.name\n\t\t\t\t\t}}</ion-item>\n\t\t\t\t</ion-list>\n\t\t</ion-toolbar>\n\t</ion-header>\n\n\t<ion-router-outlet style=\"margin-top: 76px;\" id=\"main\"></ion-router-outlet>\n</ion-app>\n";
      /***/
    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "54vc");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "VYYF");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/platform-browser/animations */
      "R1ws");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @ionic-native/http/ngx */
      "XSEc");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_common_locales_bg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/common/locales/bg */
      "lvR3");
      /* harmony import */


      var _angular_common_locales_bg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_bg__WEBPACK_IMPORTED_MODULE_13__);
      /* harmony import */


      var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @ionic-native/background-mode/ngx */
      "1xeP");
      /* harmony import */


      var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @ionic-native/local-notifications/ngx */
      "Bg0J"); //locale


      Object(_angular_common__WEBPACK_IMPORTED_MODULE_12__["registerLocaleData"])(_angular_common_locales_bg__WEBPACK_IMPORTED_MODULE_13___default.a);

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__["BrowserAnimationsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"]],
        providers: [_ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_14__["BackgroundMode"], _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_15__["LocalNotifications"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_11__["HTTP"], {
          provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
          useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
        }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
      })], AppModule);
      /***/
    },

    /***/
    "dwY0":
    /*!*********************************************!*\
      !*** ./src/app/services/network.service.ts ***!
      \*********************************************/

    /*! exports provided: NetworkService */

    /***/
    function dwY0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NetworkService", function () {
        return NetworkService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");

      var NetworkService = /*#__PURE__*/function () {
        function NetworkService(http, toastController) {
          _classCallCheck(this, NetworkService);

          this.http = http;
          this.toastController = toastController; // private baseUrl = 'https://bg.app.legaltrek.com';

          this.baseUrl = '/backend';
        }

        _createClass(NetworkService, [{
          key: "get",
          value: function get(path, params) {
            var _this6 = this;

            var request = this.http.get(this.makeUrl(path));
            return request.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(function (err) {
              return _this6.onError(err);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (res) {
              return _this6.parseResponse(res);
            }));
          }
        }, {
          key: "post",
          value: function post(path, body) {
            var _this7 = this;

            var request = this.http.post(this.makeUrl(path), body, {});
            return request.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(function (err) {
              return _this7.onError(err);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (res) {
              return _this7.parseResponse(res);
            }));
          }
        }, {
          key: "parseResponse",
          value: function parseResponse(response) {
            if (!response.success) {
              this.presentToast("Server error: ".concat(response.result.message));
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(response.result);
            }

            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(response.result);
          }
        }, {
          key: "makeUrl",
          value: function makeUrl(path) {
            return this.baseUrl + path;
          }
        }, {
          key: "onError",
          value: function onError(err) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var toast;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.toastController.create({
                        message: err.message,
                        buttons: ['OK']
                      });

                    case 2:
                      toast = _context3.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "presentToast",
          value: function presentToast(message) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var toast;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.toastController.create({
                        message: message,
                        buttons: ['OK']
                      });

                    case 2:
                      toast = _context4.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }]);

        return NetworkService;
      }();

      NetworkService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }];
      };

      NetworkService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], NetworkService);
      /***/
    },

    /***/
    "kLfG":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*****************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function kLfG(module, exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet-ios.entry.js": ["bnjm", "common", 0],
        "./ion-action-sheet-md.entry.js": ["utt2", "common", 1],
        "./ion-alert-ios.entry.js": ["yaSn", "common", 2],
        "./ion-alert-md.entry.js": ["2/RY", "common", 3],
        "./ion-app_8-ios.entry.js": ["iInF", "common", 4],
        "./ion-app_8-md.entry.js": ["K9Nc", "common", 5],
        "./ion-avatar_3-ios.entry.js": ["hH1s", "common", 6],
        "./ion-avatar_3-md.entry.js": ["Jw9y", "common", 7],
        "./ion-back-button-ios.entry.js": ["ouVF", "common", 8],
        "./ion-back-button-md.entry.js": ["/joy", "common", 9],
        "./ion-backdrop-ios.entry.js": ["uJLv", 10],
        "./ion-backdrop-md.entry.js": ["fSmE", 11],
        "./ion-button_2-ios.entry.js": ["s1jK", "common", 12],
        "./ion-button_2-md.entry.js": ["Wou7", "common", 13],
        "./ion-card_5-ios.entry.js": ["qshq", "common", 14],
        "./ion-card_5-md.entry.js": ["Q1uX", "common", 15],
        "./ion-checkbox-ios.entry.js": ["059i", "common", 16],
        "./ion-checkbox-md.entry.js": ["eLfv", "common", 17],
        "./ion-chip-ios.entry.js": ["+FzG", "common", 18],
        "./ion-chip-md.entry.js": ["yRpg", "common", 19],
        "./ion-col_3.entry.js": ["/CAe", 20],
        "./ion-datetime_3-ios.entry.js": ["Z1Jy", "common", 21],
        "./ion-datetime_3-md.entry.js": ["X0Dk", "common", 22],
        "./ion-fab_3-ios.entry.js": ["wvyA", "common", 23],
        "./ion-fab_3-md.entry.js": ["NkKY", "common", 24],
        "./ion-img.entry.js": ["wHD8", 25],
        "./ion-infinite-scroll_2-ios.entry.js": ["nf6t", 26],
        "./ion-infinite-scroll_2-md.entry.js": ["lg/V", 27],
        "./ion-input-ios.entry.js": ["sdJS", "common", 28],
        "./ion-input-md.entry.js": ["uQUw", "common", 29],
        "./ion-item-option_3-ios.entry.js": ["Pa1g", "common", 30],
        "./ion-item-option_3-md.entry.js": ["KTnd", "common", 31],
        "./ion-item_8-ios.entry.js": ["Z51p", "common", 32],
        "./ion-item_8-md.entry.js": ["8bam", "common", 33],
        "./ion-loading-ios.entry.js": ["J3Yu", "common", 34],
        "./ion-loading-md.entry.js": ["N3W9", "common", 35],
        "./ion-menu_3-ios.entry.js": ["IlGI", "common", 36],
        "./ion-menu_3-md.entry.js": ["WHty", "common", 37],
        "./ion-modal-ios.entry.js": ["mgaC", "common", 38],
        "./ion-modal-md.entry.js": ["EpFf", "common", 39],
        "./ion-nav_2.entry.js": ["vnES", "common", 40],
        "./ion-popover-ios.entry.js": ["Gdks", "common", 41],
        "./ion-popover-md.entry.js": ["VgKV", "common", 42],
        "./ion-progress-bar-ios.entry.js": ["0PGG", "common", 43],
        "./ion-progress-bar-md.entry.js": ["h/Bu", "common", 44],
        "./ion-radio_2-ios.entry.js": ["5bK7", "common", 45],
        "./ion-radio_2-md.entry.js": ["pOmE", "common", 46],
        "./ion-range-ios.entry.js": ["5g9+", "common", 47],
        "./ion-range-md.entry.js": ["fD4w", "common", 48],
        "./ion-refresher_2-ios.entry.js": ["CXux", "common", 49],
        "./ion-refresher_2-md.entry.js": ["RODS", "common", 50],
        "./ion-reorder_2-ios.entry.js": ["IdzL", "common", 51],
        "./ion-reorder_2-md.entry.js": ["Ftzj", "common", 52],
        "./ion-ripple-effect.entry.js": ["STjf", 53],
        "./ion-route_4.entry.js": ["k5eQ", "common", 54],
        "./ion-searchbar-ios.entry.js": ["l0q3", "common", 55],
        "./ion-searchbar-md.entry.js": ["mLlG", "common", 56],
        "./ion-segment_2-ios.entry.js": ["Iymp", "common", 57],
        "./ion-segment_2-md.entry.js": ["3msy", "common", 58],
        "./ion-select_3-ios.entry.js": ["rYLK", "common", 59],
        "./ion-select_3-md.entry.js": ["WOXB", "common", 60],
        "./ion-slide_2-ios.entry.js": ["F/Xn", 61],
        "./ion-slide_2-md.entry.js": ["k8us", 62],
        "./ion-spinner.entry.js": ["nI0H", "common", 63],
        "./ion-split-pane-ios.entry.js": ["edcM", 64],
        "./ion-split-pane-md.entry.js": ["RyPD", 65],
        "./ion-tab-bar_2-ios.entry.js": ["DP4G", "common", 66],
        "./ion-tab-bar_2-md.entry.js": ["gaXT", "common", 67],
        "./ion-tab_2.entry.js": ["TpdJ", "common", 68],
        "./ion-text.entry.js": ["ISmu", "common", 69],
        "./ion-textarea-ios.entry.js": ["xNZy", "common", 70],
        "./ion-textarea-md.entry.js": ["p1XJ", "common", 71],
        "./ion-toast-ios.entry.js": ["XGfm", "common", 72],
        "./ion-toast-md.entry.js": ["Y/uG", "common", 73],
        "./ion-toggle-ios.entry.js": ["WbT0", "common", 74],
        "./ion-toggle-md.entry.js": ["upP9", "common", 75],
        "./ion-virtual-scroll.entry.js": ["8Mb5", 76]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "kLfG";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "qXBG":
    /*!**************************************!*\
      !*** ./src/app/auth/auth.service.ts ***!
      \**************************************/

    /*! exports provided: AuthService */

    /***/
    function qXBG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthService", function () {
        return AuthService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _services_network_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/network.service */
      "dwY0");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var AuthService = /*#__PURE__*/function () {
        function AuthService(network, router) {
          _classCallCheck(this, AuthService);

          this.network = network;
          this.router = router;
        }

        _createClass(AuthService, [{
          key: "login",
          value: function login(loginDto) {
            return this.network.post('/api/login', loginDto);
          }
        }, {
          key: "logout",
          value: function logout() {
            this.router.navigateByUrl('/auth/login');
          }
        }]);

        return AuthService;
      }();

      AuthService.ctorParameters = function () {
        return [{
          type: _services_network_service__WEBPACK_IMPORTED_MODULE_2__["NetworkService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }];
      };

      AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AuthService);
      /***/
    },

    /***/
    "rayq":
    /*!********************************************!*\
      !*** ./src/app/matters/matters.service.ts ***!
      \********************************************/

    /*! exports provided: MattersService */

    /***/
    function rayq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MattersService", function () {
        return MattersService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _services_network_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/network.service */
      "dwY0");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");

      var MattersService = /*#__PURE__*/function () {
        function MattersService(network) {
          _classCallCheck(this, MattersService);

          this.network = network;
          this.currentMatter = null;
        }

        _createClass(MattersService, [{
          key: "getMatters",
          value: function getMatters() {
            return this.network.get('/api/get/matters');
          }
        }, {
          key: "getTaskById",
          value: function getTaskById(id) {
            var url = "/api/tasks/".concat(id);
            return this.network.get(url);
          }
        }, {
          key: "getMatterDetails",
          value: function getMatterDetails(matterId) {
            console.log('getting details for:' + matterId);
            return this.network.get('/api/get/matter/' + matterId);
          }
        }, {
          key: "search",
          value: function search(term) {
            return this.network.post('/search/quick', {
              query: term
            });
          }
        }, {
          key: "addMatter",
          value: function addMatter(data) {
            console.log(data);
          }
        }, {
          key: "changeTaskStatus",
          value: function changeTaskStatus() {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(true).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["delay"])(1000));
          }
        }]);

        return MattersService;
      }();

      MattersService.ctorParameters = function () {
        return [{
          type: _services_network_service__WEBPACK_IMPORTED_MODULE_2__["NetworkService"]
        }];
      };

      MattersService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], MattersService);
      /***/
    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var routes = [{
        path: 'auth',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | auth-auth-module */
          [__webpack_require__.e("default~auth-auth-module~billings-billings-module~matters-matters-module"), __webpack_require__.e("auth-auth-module")]).then(__webpack_require__.bind(null,
          /*! ./auth/auth.module */
          "Yj9t")).then(function (m) {
            return m.AuthModule;
          });
        }
      }, {
        path: 'home',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | home-home-module */
          "home-home-module").then(__webpack_require__.bind(null,
          /*! ./home/home.module */
          "ct+p")).then(function (m) {
            return m.HomePageModule;
          });
        }
      }, {
        path: '',
        redirectTo: 'auth',
        pathMatch: 'full'
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
          relativeLinkResolution: 'legacy'
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AppRoutingModule);
      /***/
    },

    /***/
    "ynWL":
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /*! exports provided: default */

    /***/
    function ynWL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".sidemenu-container {\n  display: flex;\n  flex-direction: column;\n}\n\n.spacer {\n  flex: 1 1 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsYUFBQTtFQUNBLHNCQUFBO0FBQ0Q7O0FBRUE7RUFDQyxjQUFBO0FBQ0QiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNpZGVtZW51LWNvbnRhaW5lciB7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG4uc3BhY2VyIHtcclxuXHRmbGV4OiAxIDEgYXV0bztcclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      "a3Wg");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "ZAI4");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.log(err);
      });
      /***/
    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map